# OrynKit — Brand Consistency Playbook

**Goal:** Apply a single, consistent brand system across all OrynKit surfaces (Starter, Lifetime, Tally, Emails, Gumroad, SOP PDFs, PWA). Import this into Notion for tracking and execution.

---

## ✅ Master Checklist (Do These First)
- [ ] Create `/assets/` (no spaces, lowercase, kebab-case) and move all images/icons there
- [ ] Create `/css/brand.css` and `/css/components.css`, import on **every** page
- [ ] Standardize CTAs to the shared `.btn` component
- [ ] Add OG/Twitter meta tags per page and upload `/assets/og/*`
- [ ] Update `site.webmanifest` + icons under `/assets/icons/`
- [ ] Add UTM parameters to all outbound Gumroad links
- [ ] QA: desktop/tablet/mobile parity, contrast, assets 200s, share card previews

---

## 1) Brand Tokens & Assets (Single Source of Truth)

### CSS tokens (`/css/brand.css`)
```css
:root{
  --bg:#120029; --ink:#EAD7FF; --muted:#C9B2FF;
  --card:#1B0140; --line:rgba(192,132,252,.35);
  --accent:#C084FC; --accent2:#A855F7; --ring:#7C3AED;
  --ok:#9EF8D1; --warn:#FFD28F;
  --radius:22px; --radius-sm:12px; --shadow:0 16px 48px rgba(0,0,0,.25);
  --font: Inter, Segoe UI, system-ui, -apple-system, sans-serif;
}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;font-family:var(--font);color:var(--ink);background:var(--bg);}
a{color:inherit}
```

### Components (`/css/components.css`)
```css
.card{background:var(--card);border:1px solid var(--line);
  border-radius:var(--radius);box-shadow:var(--shadow);padding:26px}

.badge{display:inline-flex;gap:8px;align-items:center;
  background:rgba(192,132,252,.12);border:1px solid var(--line);
  color:var(--muted);padding:6px 10px;border-radius:999px;font-size:12px}

.btn{display:inline-block;text-decoration:none;text-align:center;
  padding:14px 22px;border-radius:14px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  color:#090016;border:1px solid rgba(234,215,255,.45);
  box-shadow:0 10px 28px rgba(168,85,247,.45);transition:.15s transform, .15s filter}
.btn:hover{transform:translateY(-1px);filter:brightness(1.05)}
.btn:focus{outline:2px solid var(--ring);outline-offset:3px}
```

### Asset System (structure)
```
/assets/
  brand/
    orynkit-logo-text.svg
    orynkit-logo-mark.svg
  icons/
    favicon-16x16.png
    favicon-32x32.png
    android-chrome-192x192.png
    apple-touch-icon.png
    site.webmanifest
  og/
    og-starter.png
    og-lifetime.png
```

---

## 2) Websites (Starter / Lifetime / Any Landing)

- Use `/assets/...` paths (no spaces/parentheses).
- Import the **same** CSS files on all pages:
```html
<link rel="stylesheet" href="/css/brand.css">
<link rel="stylesheet" href="/css/components.css">
```
- **Consistent radii & shadow**: use `--radius`, `--shadow` only.
- **CTA**: always use `.btn` class (no inline styles).

### OG/SEO Meta (per page)
```html
<meta property="og:type" content="website">
<meta property="og:title" content="OrynKit — SOP Assistant (Lifetime)">
<meta property="og:description" content="Unlimited SOPs. Branded outputs. Early access to the Oryn AI Agent Builder Kit.">
<meta property="og:image" content="/assets/og/og-lifetime.png">
<meta name="twitter:card" content="summary_large_image">
```

### Manifest & Theme
```html
<link rel="manifest" href="/assets/icons/site.webmanifest">
<meta name="theme-color" content="#120029">
```

---

## 3) Gumroad Product Pages (Starter + Pro/Lifetime)

- Covers & thumbnails: same palette, rounded-card motif, “by Purple Cove Labs” footer.
- Copy sequence: **Headline → Benefit → Price → Credibility**.
- Add UTMs to links:  
`?utm_source=site&utm_medium=cta&utm_campaign=orynkit_launch`

---

## 4) Tally Form (Entry Point)
- Logo: `/assets/brand/orynkit-logo-text.svg`
- Theme colors: background `#120029`, accent `#A855F7`, text `#EAD7FF`
- Success screen uses the same `.btn` style and tone.

---

## 5) Email Delivery (Zapier → Gmail)

### Branded CTA (inline CSS; Gmail-safe)
```html
<a href="{{payment_or_cta_url}}" style="display:inline-block;padding:14px 22px;border-radius:14px;
background:linear-gradient(135deg,#C084FC,#A855F7);color:#090016;text-decoration:none;
border:1px solid rgba(234,215,255,.45);box-shadow:0 10px 28px rgba(168,85,247,.45)">Open Your SOP</a>
```
- From-name: **“OrynKit — Purple Cove Labs”**  
- Footer matches brand colors and typography.

---

## 6) SOP Output (Email Body + PDF)

- Sections: Headline, Numbered Steps, **Do/Don’t**, QA Checks.
- Colors: H1 `#EAD7FF`, H2 `#C9B2FF`, body `#EAD7FF` on `#120029` bg.
- PDFs: header/footer with logo mark, purple rule, page numbers.
- Exports to Notion/Sheets: prepend a short brand header + purple rule for continuity.

---

## 7) PWA & Icons

- `site.webmanifest` points to `/assets/icons/` icons; theme/background `#120029`.
- Favicon links in `<head>` across all pages; verify they resolve (no 404s).

---

## 8) Analytics & URLs

- Standardize outbound links with UTM params.
- Netlify rewrites (optional) to migrate old image paths → `/assets/...`.
- Cache busting via fingerprinting or `?v=1.0.0` query strings.

---

## 9) QA Checklist (15 Minutes)

- [ ] **Visual parity:** Starter vs Lifetime on desktop/tablet/mobile (paddings, radii, shadows, font stack)
- [ ] **Contrast:** `#A855F7` on `#1B0140` — ensure readability (increase size/weight if needed)
- [ ] **Assets:** all `/assets/...` URLs return **200** (case-sensitive on Netlify)
- [ ] **Share cards:** OG/Twitter previews show correct title, description, and image
- [ ] **Flow:** Tally → Email → Gumroad link (with UTM) works end-to-end

---

## 10) Governance (Prevent Drift)

- **Token-only styling:** reject raw hex in PRs (search for `#` in diffs).
- **Styleguide page:** quick page listing button, card, badge, headings for pre-deploy eyeball QA.
- **Naming rules:** kebab-case, lowercase extensions, no spaces/parentheses.

---

## Quick Wins (Today)

1. Move all images to `/assets/…`, rename web-safe, update paths.  
2. Add `brand.css` + `components.css`, import on Starter + Lifetime pages.  
3. Swap all CTAs to `.btn`.  
4. Add OG meta to both pages and upload `/assets/og/*`.  
5. Paste the Gmail inline CTA button into your Zapier Gmail HTML step.

---

## Appendix — Starter Snippets

### Minimal Page Head (importing shared CSS)
```html
<link rel="stylesheet" href="/css/brand.css">
<link rel="stylesheet" href="/css/components.css">
<link rel="manifest" href="/assets/icons/site.webmanifest">
<meta name="theme-color" content="#120029">
```

### CTA Button (HTML)
```html
<a class="btn" href="https://gum.co/orynkit-lifetime?utm_source=site&utm_medium=cta&utm_campaign=orynkit_launch">
  Get Lifetime — $59.99
</a>
```

### Example Card Block (HTML)
```html
<div class="card">
  <h3 style="margin-top:0">What you get</h3>
  <ul style="margin:0;padding-left:18px">
    <li>Unlimited SOPs</li>
    <li>Branded outputs</li>
    <li>Notion/Sheets exports</li>
  </ul>
</div>
```
